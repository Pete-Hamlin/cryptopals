#!/usr/bin/python

# CODE NOW WORKS AS INTENDED - ONLY MODIFY VARIABLES

KEYSIZE=2
MAX_KEYSIZE=40
KEYS = 10
#select_arr = []

# hamming distance calculator (test)
#str1= "this is a test"
#str2= "wokka wokka!!!"




def dist(strl, keysize):
	diff = 0
	dat = []
	for i in strl:							# Convert into binary formatted string
		i = bin(int(i.encode("hex"), 16)).replace("0b", "")
		#print len(i)
		if len(i) != (keysize*8):             			# 0 Pad if not present
			i = i.zfill(keysize*8)
                        #print i
			#print len(i)
		dat.append(i)

		for d in range(len(dat)-1):
			for i in range(len(dat[d])):
        			if dat[d][i] != dat[d+1][i]:
        				diff += 1
	diff = diff/(len(dat)-1)
	return diff

# Main function
while KEYSIZE <= MAX_KEYSIZE:

	f = open('6.txt', 'r')

	# hamming distance calculator (test)
	#str[0]= "this is a test"
	#str[1]= "wokka wokka!!!"

	# Actual hamming distance calculator
	strl = []

	for i in range(KEYS):
		strl.append(f.read(KEYSIZE))
	f.close()


	# Read test
	#print strl


	diff = dist(strl, KEYSIZE)
#	print diff
	diff = float(diff)/(KEYSIZE*(KEYS-1))
	if float(diff) < 2.0:
		print str(KEYSIZE)+": "+str(diff)
	KEYSIZE += 1
