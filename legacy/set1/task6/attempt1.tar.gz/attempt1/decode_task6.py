#!/usr/bin/python

key = 'aaua'
f = open('6.txt')

hex_data=int(f.read().encode("hex"), 16)
#hex_data = 0x0b3637272a2b2e63622c2e69692a23693a2a3c6324202d623d63343c2a26226324272765272a282b2f20430a652e2c652a3124333a653e2b2027630c692b20283165286326302e27282f
dat = hex(hex_data).replace("0x", "").replace("L", "")
#dat= dat.zfill(len(dat)+1)
print dat

# Split into 8-bit ASCII
x = 0
y = 2
arr =[]
while x < len(dat)-1:
	dec = int(dat[x:y], 16)
	arr.append(dec)
#	print chr(dec)
	x += 2
	y += 2

#print arr
i = 0
j = 0
crypt = ''
# Run through each XOR char key
while i <len(arr):
	temp = chr(arr[i]^ord(key[j]))
	crypt += temp
	i += 1
	j += 1 if j < (len(key) - 1) else -2
#	print j
print crypt#.encode("hex")
