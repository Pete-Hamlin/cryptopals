#!/usr/bin/python
KEYSIZE=20

f = open('6.txt', 'r')

split = []

# Split file into chunks of right length
while True:
	temp = f.read(KEYSIZE)
	if len(temp) != KEYSIZE:
		break
	split.append(temp)

#print split

# Transpose chunks
chunk = []
for i in range(KEYSIZE):
	temp = "".join([j[i] for j in split])
	chunk.append(temp)
#print chunk


# Split into individual HEX pairs
for line in chunk:
	data=hex(int(line.encode("hex"), 16)).replace("0x", "").replace("L","")
#	print data
	x = 0
	y = 2
	in_arr = []
	while x < len(data)-2:
		dec = int(data[x:y], 16)
		in_arr.append(dec)
#	    print chr(dec)
		x += 2
		y += 2
#
# #	print in_arr
#
# Generate output
	for i in range(32, 126):			# Likely used ASCII characters
		temp = ''
		out_arr = {}
		temp_count = 0
		for j in in_arr:				# XOR
			code = j^i
			if code == 0x20:
				temp_count += 1
		out_arr[chr(i)] = temp_count
		print out_arr

	for i in range(10):
		print ""





# 	Formerly lines 48-62

#			out_arr.append(code)
#			temp += chr(code)
#		print chr(i)
#		clean = ""
#		for y in out_arr:
#			if y in range(32, 126):
#				clean += chr(y)
#		if len(clean) > 800:
#			print chr(i)
#			print clean
#			print len(clean)
#			for i in range(2):				# Make things pretty
#				print ""
#	for i in range(10):
#		print ""
